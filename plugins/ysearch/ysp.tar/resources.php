<?php

class ResourceChildSorter
{
	private $order;

	public function __construct($order)
	{
		$this->order = $order;
	}

	public function sort($a, $b)
	{
		$a_id = $a->get('id');
		$b_id = $b->get('id');
		$sec_diff = strcmp($a->get_section(), $b->get_section());
		if ($sec_diff < 0)
			return -1;
		if ($sec_diff > 0)
			return 1;
		$a_ord = $this->order[$a_id];
		$b_ord = $this->order[$b_id];
		return $a_ord == $b_ord ? 0 : $a_ord < $b_ord ? -1 : 1;
	}
}

class plgYSearchResources extends YSearchPlugin
{
	public static function onYSearch($terms, &$results)
	{
		$weight = 'match(r.title, r.introtext, r.`fulltext`) against (\''.join(' ', $terms['stemmed']).'\')';
			
		$addtl_where = array();
		foreach ($terms['mandatory'] as $mand)
			$addtl_where[] = "(r.title LIKE '%$mand%' OR r.introtext LIKE '%$mand%' OR r.`fulltext` LIKE '%$mand%')";
		foreach ($terms['forbidden'] as $forb)
			$addtl_where[] = "(r.title NOT LIKE '%$forb%' AND r.introtext NOT LIKE '%$forb%' AND r.`fulltext` NOT LIKE '%$forb%')";
		
		# (select group_concat(child_id) from jos_resource_assoc ra inner join jos_resources re2 on re2.id = ra.child_id and re2.standalone where ra.parent_id = r.id) AS children,
		$sql = new YSearchResultSQL(
			"SELECT
				r.id,
				r.title,
				concat(coalesce(r.introtext, ''), coalesce(r.`fulltext`, '')) AS description,
				concat('/resources/', r.id) AS link,
				$weight AS weight,
				r.publish_up AS date,
				rt.type AS section,
				(SELECT group_concat(u1.name separator '\\n') FROM jos_author_assoc anames INNER JOIN jos_users u1 ON u1.id = anames.authorid WHERE subtable = 'resources' AND subid = r.id) AS contributors,
				(SELECT group_concat(ids.authorid separator '\\n') FROM jos_author_assoc ids WHERE subtable = 'resources' AND subid = r.id) AS contributor_ids,
				(select group_concat(concat(parent_id, '|', ordering)) 
					from jos_resource_assoc ra2 
					inner join jos_resources re3 on re3.id = ra2.parent_id and re3.standalone 
					where ra2.child_id = r.id) AS parents
			FROM jos_resources r
			LEFT JOIN jos_resource_types rt 
				ON rt.id = r.type
			WHERE 
				r.published AND r.standalone AND NOT r.access AND (r.publish_up AND NOW() > r.publish_up) AND (NOT r.publish_down OR NOW() < r.publish_down) 
				AND $weight > 0".
				($addtl_where ? ' AND ' . join(' AND ', $addtl_where) : '').
			" ORDER BY $weight DESC"
		);
		$assoc = $sql->to_associative();

		$id_assoc = array();
		foreach ($assoc as $row)
			$id_assoc[$row->get('id')] = $row;
		
		$placed = array();
		foreach ($assoc as $row)
		{
			$parents = $row->get('parents');
			foreach (split(',', $parents) as $parent)
			{
				list($parent_id, $ordering, $type) = split('\|', $parent);
				if (array_key_exists((int)$parent_id, $id_assoc))
				{
					$placed[(int)$row->get('id')] = $ordering;
					$id_assoc[(int)$parent_id]->add_child($row);
					$id_assoc[(int)$parent_id]->add_weight($row->get_weight()/10);
				}
			}
		}
		
		$sorter = new ResourceChildSorter($placed);
		$rows = array();
		foreach ($id_assoc as $id=>$row)
			if (!array_key_exists((int)$id, $placed))
			{
				$row->sort_children(array($sorter, 'sort'));
				$rows[] = $row;
			}

		usort($rows, create_function('$a, $b', 'return (($res = $a->get_weight() - $b->get_weight()) == 0 ? 0 : $res > 0 ? -1 : 1);'));
		foreach ($rows as $row)
			$results->add($row);
	}

	public static function onYSearchCustom($terms, &$results)
	{
		return false;

		if (!preg_match('/^\s*?((?:[a-z]{3,4})?\s*?\d{3}[a-z]?)\s*$/', strtolower($terms->get_raw()), $match))
			return false;

		$course = $match[1];

		# get courses
		$sql = new YSearchResultSQL(
			'SELECT re.id, re.title, re.created, concat(coalesce(re.introtext, \'\'), coalesce(re.`fulltext`, \'\')) AS description, concat(\'/resources/\', re.id) AS link, publish_up AS date, \'Courses\' AS section
			FROM jos_resources re
			INNER JOIN jos_resource_types rt
				ON rt.id = re.type AND rt.type = \'Courses\'
			WHERE re.published AND re.standalone AND NOT re.access AND (re.publish_up AND NOW() > re.publish_up) AND (NOT re.publish_down OR NOW() < re.publish_down) AND title LIKE \'%'.$course.'%\'
			ORDER BY date DESC'
		);
		$assoc = $sql->to_associative();
		$course_order = array();
		foreach ($assoc as $idx=>$c)
		{
			$cid = $c->get('id');
			$course_order[] = "WHEN (SELECT 1 FROM jos_resource_assoc WHERE parent_id = $cid AND child_id = re.id) THEN $idx";
			$results->add($c);
		}
		if (!$course_order)
			return false;
		$course_order = 'CASE ' . join("\n", $course_order) . ' ELSE ' . ($idx + 1) . ' END';
		
		# get lectures and course materials
		$sql = new YSearchResultSQL(
			"SELECT re.id, re.title, re.created, concat(coalesce(re.introtext, ''), coalesce(re.`fulltext`, '')) AS description, concat('/resources/', re.id) AS link, publish_up AS date, rt.type AS section,
				(SELECT ordering FROM jos_resource_assoc ra2 WHERE ra2.child_id = re.id LIMIT 1) AS sequence
			FROM jos_resources re
			LEFT JOIN jos_resource_types rt
				ON rt.id = re.type
			WHERE re.published AND re.standalone AND NOT re.access AND (re.publish_up AND NOW() > re.publish_up) AND (NOT re.publish_down OR NOW() < re.publish_down) AND title LIKE '%$course%' AND rt.type != 'Courses'
			ORDER BY $course_order, sequence"
		);
		foreach ($sql->to_associative() as $row)
			$results->add($row);
		return 'course results';
	}
}
